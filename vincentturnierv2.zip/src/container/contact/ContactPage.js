import React from 'react';


export default function ContactPage(props){

    return (
        <div>

        </div>
    );
};